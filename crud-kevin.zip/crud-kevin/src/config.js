export const urldb='mongodb+srv://messi:kevin6605@messi.ttxvq2e.mongodb.net/';

export const TOKEN_SECRET = 'secret123';
